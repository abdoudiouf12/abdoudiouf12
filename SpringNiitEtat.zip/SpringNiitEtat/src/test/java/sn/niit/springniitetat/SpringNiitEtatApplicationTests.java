package sn.niit.springniitetat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringNiitEtatApplicationTests {

	@Test
	void contextLoads() {
	}

}
