package sn.niit.springniitetat.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController 
{
	@RequestMapping("/")
	public String hello(Model model)
	{
		model.addAttribute("message", "Hello World depuis Spring Boot");
		return "home";
	}
	
	@RequestMapping("/apropos")
	public String apropos(Model model)
	{
		model.addAttribute("message", "Hello World depuis Spring Boot");
		return "apropos";
	}
	
	@RequestMapping("/faq")
	public String faq(Model model)
	{
		model.addAttribute("message", "Hello World depuis Spring Boot");
		return "faq";
	}
	
	@RequestMapping("/contact")
	public String contact(Model model)
	{
		model.addAttribute("message", "Hello World depuis Spring Boot");
		return "contact";
	}

}
